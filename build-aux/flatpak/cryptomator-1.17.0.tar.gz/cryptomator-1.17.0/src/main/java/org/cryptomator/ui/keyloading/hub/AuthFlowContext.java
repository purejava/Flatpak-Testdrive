package org.cryptomator.ui.keyloading.hub;

record AuthFlowContext(String deviceId) {

}
