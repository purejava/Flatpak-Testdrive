package org.cryptomator.common;

/**
 * Replacement for JSR-305 to avoid runtime dependencies. Used in Dagger components.
 */
public @interface Nullable {

}
