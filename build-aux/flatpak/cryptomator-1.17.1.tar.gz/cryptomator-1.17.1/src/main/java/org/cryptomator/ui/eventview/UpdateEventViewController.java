package org.cryptomator.ui.eventview;

import org.cryptomator.ui.common.FxController;

import javax.inject.Inject;

@EventViewScoped
public class UpdateEventViewController implements FxController {

	@Inject
	public UpdateEventViewController() {

	}
}
