package org.cryptomator.common.locationpresets;

import java.nio.file.Path;

public record LocationPreset(String name, Path path) {



}
