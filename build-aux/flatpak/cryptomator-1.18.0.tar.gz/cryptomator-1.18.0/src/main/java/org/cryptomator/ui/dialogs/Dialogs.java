package org.cryptomator.ui.dialogs;

import org.cryptomator.common.settings.Settings;
import org.cryptomator.common.vaults.Vault;
import org.cryptomator.ui.common.DefaultSceneFactory;
import org.cryptomator.ui.common.StageFactory;
import org.cryptomator.ui.controls.FontAwesome5Icon;
import org.cryptomator.ui.fxapp.FxApplicationScoped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import java.util.ResourceBundle;
import java.util.function.Consumer;

@FxApplicationScoped
public class Dialogs {

	private final ResourceBundle resourceBundle;
	private final StageFactory stageFactory;
	private final DefaultSceneFactory sceneFactory;

	private static final String BUTTON_KEY_CLOSE = "generic.button.close";

	@Inject
	public Dialogs(ResourceBundle resourceBundle, StageFactory stageFactory, DefaultSceneFactory sceneFactory) {
		this.resourceBundle = resourceBundle;
		this.stageFactory = stageFactory;
		this.sceneFactory = sceneFactory;
	}

	private static final Logger LOG = LoggerFactory.getLogger(Dialogs.class);

	private SimpleDialog.Builder createDialogBuilder() {
		return new SimpleDialog.Builder(resourceBundle, stageFactory, sceneFactory);
	}

	public SimpleDialog.Builder prepareRemoveVaultDialog(Stage window, Vault vault, ObservableList<Vault> vaults) {
		return createDialogBuilder().setOwner(window) //
				.setTitleKey("removeVault.title", vault.getDisplayName()) //
				.setMessageKey("removeVault.message") //
				.setDescriptionKey("removeVault.description") //
				.setIcon(FontAwesome5Icon.QUESTION) //
				.setOkButtonKey("generic.button.remove") //
				.setCancelButtonKey("generic.button.cancel") //
				.setOkAction(stage -> {
					LOG.debug("Removing vault {}.", vault.getDisplayName());
					vaults.remove(vault);
					stage.close();
				});
	}

	public SimpleDialog.Builder prepareContactHubVaultOwner(Stage window) {
		return createDialogBuilder().setOwner(window) //
				.setTitleKey("contactHubVaultOwner.title") //
				.setMessageKey("contactHubVaultOwner.message") //
				.setDescriptionKey("contactHubVaultOwner.description") //
				.setIcon(FontAwesome5Icon.EXCLAMATION)//
				.setOkButtonKey(BUTTON_KEY_CLOSE);
	}

	public SimpleDialog.Builder prepareRecoveryVaultAdded(Stage window, String displayName) {
		return createDialogBuilder().setOwner(window) //
				.setTitleKey("recover.existing.title") //
				.setMessageKey("recover.existing.message") //
				.setDescriptionKey("recover.existing.description", displayName) //
				.setIcon(FontAwesome5Icon.CHECK)//
				.setOkButtonKey(BUTTON_KEY_CLOSE);
	}
	public SimpleDialog.Builder prepareRecoveryVaultAlreadyExists(Stage window, String displayName) {
		return createDialogBuilder().setOwner(window) //
				.setTitleKey("recover.alreadyExists.title") //
				.setMessageKey("recover.alreadyExists.message") //
				.setDescriptionKey("recover.alreadyExists.description", displayName) //
				.setIcon(FontAwesome5Icon.EXCLAMATION)//
				.setOkButtonKey(BUTTON_KEY_CLOSE);
	}

	public SimpleDialog.Builder prepareRecoverPasswordSuccess(Stage window) {
		return createDialogBuilder()
				.setOwner(window) //
				.setTitleKey("recoveryKey.recover.title") //
				.setMessageKey("recoveryKey.recover.resetSuccess.message") //
				.setDescriptionKey("recoveryKey.recover.resetSuccess.description") //
				.setIcon(FontAwesome5Icon.CHECK)
				.setOkAction(Stage::close)
				.setOkButtonKey(BUTTON_KEY_CLOSE);
	}

	public SimpleDialog.Builder prepareRemoveCertDialog(Stage window, Settings settings) {
		return createDialogBuilder() //
				.setOwner(window) //
				.setTitleKey("removeCert.title") //
				.setMessageKey("removeCert.message") //
				.setDescriptionKey("removeCert.description") //
				.setIcon(FontAwesome5Icon.QUESTION) //
				.setOkButtonKey("generic.button.remove") //
				.setCancelButtonKey("generic.button.cancel") //
				.setOkAction(stage -> {
					settings.licenseKey.set(null);
					stage.close();
				});
	}

	public SimpleDialog.Builder prepareDokanySupportEndDialog(Stage window, Consumer<Stage> cancelAction) {
		return createDialogBuilder() //
				.setOwner(window) //
				.setTitleKey("dokanySupportEnd.title") //
				.setMessageKey("dokanySupportEnd.message") //
				.setDescriptionKey("dokanySupportEnd.description") //
				.setIcon(FontAwesome5Icon.EXCLAMATION) //
				.setOkButtonKey(BUTTON_KEY_CLOSE) //
				.setCancelButtonKey("dokanySupportEnd.preferencesBtn") //
				.setOkAction(Stage::close) //
				.setCancelAction(cancelAction);
	}

	public SimpleDialog.Builder prepareRetryIfReadonlyDialog(Stage window, Consumer<Stage> okAction) {
		return createDialogBuilder() //
				.setOwner(window) //
				.setTitleKey("retryIfReadonly.title") //
				.setMessageKey("retryIfReadonly.message") //
				.setDescriptionKey("retryIfReadonly.description") //
				.setIcon(FontAwesome5Icon.EXCLAMATION) //
				.setOkButtonKey("retryIfReadonly.retry") //
				.setCancelButtonKey(BUTTON_KEY_CLOSE) //
				.setOkAction(okAction) //
				.setCancelAction(Stage::close);
	}

	public SimpleDialog.Builder prepareNoDDirectorySelectedDialog(Stage window) {
		return createDialogBuilder() //
				.setOwner(window) //
				.setTitleKey("recover.invalidSelection.title") //
				.setMessageKey("recover.invalidSelection.message") //
				.setDescriptionKey("recover.invalidSelection.description") //
				.setIcon(FontAwesome5Icon.EXCLAMATION) //
				.setOkButtonKey("generic.button.change") //
				.setOkAction(Stage::close);
	}

}
