# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

The changelog starts with version 1.19.0.
Changes to prior versions can be found on the [Github release page](https://github.com/cryptomator/cryptomator/releases).

## [Unreleased](https://github.com/cryptomator/cryptomator/compare/1.18.0...HEAD)

### Added
* New Self-Update Mechanism (#3948)
  * Implemented `.dmg` update mechanism
  * Implemented Flatpak update mechanism

### Changed
* Built using JDK 25 (#4031)
* Modernized Templage for GitHub Releases